import yaml
from agents.guideline_parser import parse_guidelines
from agents.rule_generator import generate_rules
from agents.doc_generator import generate_docs

def main():
    """Orchestrator to run the A2A pipeline."""
    # Load configuration
    with open('a2a_governance/config.yaml', 'r') as f:
        config = yaml.safe_load(f)
    all_rules_config = config.get('rules', {})

    # 1. Guideline Parser Agent: Get the list of active rule IDs
    active_rule_ids = parse_guidelines('a2a_governance/guidelines/security_policies.md')

    # 2. Rule Generator Agent
    cfn_template = generate_rules(active_rule_ids, all_rules_config, 'a2a_governance/templates/rule_template.j2')
    with open('a2a_governance/output/aws-config-rules.yaml', 'w') as f:
        f.write(cfn_template)
    print("Successfully generated CloudFormation template.")

    # 3. Documentation Generator Agent
    markdown_doc = generate_docs(active_rule_ids, all_rules_config, 'a2a_governance/templates/doc_template.j2')
    with open('a2a_governance/output/aws-config-rules.md', 'w') as f:
        f.write(markdown_doc)
    print("Successfully generated Markdown documentation.")

if __name__ == "__main__":
    main()